'use strict';

module.exports = {
  reject: [
    // Todo: Old copy with jspdf which needs updating: https://github.com/SVG-Edit/svgedit/issues/51
    'underscore'
  ]
};
