What

There are over 600k SVG images total on [Wikipedia Commons](https://commons.wikimedia.org/). Imagine if all this free content was editable via SVG-edit! (and eventually translatable as well)

The 1st thing we need is RoundtripTests (worked on by Mike Baynton, based on initial ideas / work by Brion Vibber)
Who

    Brion Vibber
    Mike Baynton
    Marc Laporte
    You? (join us!)

Related links

    http://lists.wikimedia.org/pipermail/wikitech-l/2012-November/064472.html
    https://bugzilla.wikimedia.org/show_bug.cgi?id=38271
    https://github.com/brion/svg-edit-test
    http://leuksman.com/misc/svg-edit-test/ (round-trip tester pulling SVGs from Wikimedia Commons)
    https://groups.google.com/forum/#!topic/svg-edit/SfTVM4OPXiA/discussion
    https://www.mediawiki.org/wiki/Extension:SVGEdit
    https://www.mediawiki.org/wiki/Extension:TranslateSvg
    https://code.google.com/p/svg-edit/issues/detail?id=1006
    Maybe https://github.com/svg/svgo can be useful?
