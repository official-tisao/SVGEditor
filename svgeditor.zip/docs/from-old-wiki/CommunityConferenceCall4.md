The recording is here: http://tiki.bigbluebutton.org/playback/slides/playback.html?meetingId=c986d4c28a45e0f8bab246354ebfe0422683e9de-1381420089478

Previous calls: CommunityConferenceCall CommunityConferenceCall2 CommunityConferenceCall3

Next call: CommunityConferenceCall5
When

The meeting will be October 10th, 2013 (at 16h00 UTC like the previous one) Please check for the [time in your time zone](http://www.timeanddate.com/worldclock/fixedtime.html?iso=20131010T1600)
Where

Online with BigBlueButton here (no registration required)
Topics

    demo of WebAppFind (Brett Zamir)
    Follow-up on Wikipedia progress (Brion Vibber)
    RoundtripTests dashboard (Mike Baynton)
    Security fixes
    2.7 release
    Github discussion (Daniel Shapiro)

Who

Everyone is invited. Add your name below to confirm your participation. * Marc Laporte * Mike Baynton * Brion Vibber * Daniel Shapiro
Related links

    Add links here when it's official
    https://plus.google.com/107010604858430492390/posts/KkYbnyfLe5T
    https://twitter.com/SVGedit/status/385489947689369600
    http://www.linkedin.com/groups/SVGedit-4th-Community-Conference-Call-4712151.S.278209989
    https://www.facebook.com/events/161235787405818/
    https://identi.ca/
