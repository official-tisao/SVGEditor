The goal of this page is for everyone in the community to be aware of how different community members use and rely on SVG-edit. Please see ProjectsThatUseSvgEdit for the list of projects.
FOSS Web apps

    Wiki engines
    Content Management Systems
    E-learning tools
    etc.

Typical example: http://www.dokuwiki.org/plugin:svgedit
Online services with drawing needs

    Drawings for products
    T-shirts
    Web to print
    etc.

Typical example: http://instanttee.co.nr/
Installable application

Integrating SVG-edit in a desktop application, which you download and use on your computer, like http://bluegriffon.org/

See also: Consulting
