Previous calls: CommunityConferenceCall CommunityConferenceCall2 CommunityConferenceCall3 CommunityConferenceCall4

The recording is here: http://tiki.bigbluebutton.org/playback/slides/playback.html?meetingId=c986d4c28a45e0f8bab246354ebfe0422683e9de-1383839952270
When

The meeting will be November 7th, 2013 (at 16h00 UTC like the previous one but your daylight saving time may have changed) Please check for [the time in your time zone](http://www.timeanddate.com/worldclock/fixedtime.html?iso=20131107T1600)
Where

Online with BigBlueButton [here](http://tiki.org/SVG-edit+2013-11+community+meeting) (no registration required)
Topics

    demo of WebAppFind (Brett Zamir)
    Follow-up on Wikipedia progress (Brion Vibber)
    RoundtripTests dashboard (Mike Baynton)
    Security fixes
    2.7 release
    Github discussion (Daniel Shapiro)

Who

Everyone is invited. Add your name below to confirm your participation. * Marc Laporte
Related links

    Add links here when it's official
    https://plus.google.com/
    https://twitter.com/
    http://www.linkedin.com/
    https://www.facebook.com/
    https://identi.ca/
