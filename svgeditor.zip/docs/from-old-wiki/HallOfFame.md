Lukas Reschke

Special thanks to Lukas Reschke - [statuscode.ch](http://statuscode.ch/) for reporting http://code.google.com/p/svg-edit/source/detail?r=2080
