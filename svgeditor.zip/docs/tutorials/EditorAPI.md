# Editor API

This is an entry point that summarizes the documentation on the Editor.

For user-facing information about the Editor, see [Editor]{@tutorial Editor}.

The main API entrance point is with the [Editor JSDocs]{@link module:Editor}.

## Canvas-specific methods

See [Canvas]{@tutorial Canvas}.
