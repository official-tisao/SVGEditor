export default {
  name: 'WebAppFind',
  buttons: [
    {
      title: 'Save Image back to Disk'
    }
  ]
};
