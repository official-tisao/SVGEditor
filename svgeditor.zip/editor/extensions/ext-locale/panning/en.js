export default {
  name: 'Extension Panning',
  buttons: [
    {
      title: 'Panning'
    }
  ]
};
