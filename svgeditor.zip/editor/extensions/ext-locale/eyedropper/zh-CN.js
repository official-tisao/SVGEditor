export default {
  name: '滴管',
  buttons: [
    {
      title: '滴管工具',
      key: 'I'
    }
  ]
};
