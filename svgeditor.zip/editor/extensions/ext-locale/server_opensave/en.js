export default {
  uploading: 'Uploading...',
  hiddenframe: 'Opensave frame to store hidden values'
};
