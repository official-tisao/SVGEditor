export default {
  name: 'Hello World',
  text: 'Hello World!\n\n 请点击: {x}, {y}',
  buttons: [
    {
      title: "输出 'Hello World'"
    }
  ]
};
