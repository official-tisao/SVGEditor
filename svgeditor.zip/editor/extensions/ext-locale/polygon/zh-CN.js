export default {
  name: '多边形',
  buttons: [
    {
      title: '多边形工具'
    }
  ],
  contextTools: [
    {
      title: '边数',
      label: '边数'
    }
  ]
};
