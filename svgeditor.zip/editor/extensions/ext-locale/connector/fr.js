export default {
  name: 'Connector',
  langList: [
    {id: 'mode_connect', title: 'Connecter deux objets'}
  ],
  buttons: [
    {
      title: 'Connect two objects'
    }
  ]
};
