export default {
  name: '数学',
  buttons: [
    {
      title: '添加数学计算'
    }
  ]
};
