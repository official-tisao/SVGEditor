import svgEditor from './svg-editor.js';

svgEditor.setConfig({
  canvasName: 'xdomain', // Namespace this
  allowedOrigins: ['*']
});
